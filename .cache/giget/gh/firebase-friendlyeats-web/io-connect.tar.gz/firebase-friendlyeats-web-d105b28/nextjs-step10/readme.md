### Friendly Eats with Next.js + Firebase App Hosting

This is a version of Friendly Eats optimized to work with Firebase App Hosting.

https://firebase.google.com/codelabs/firebase-nextjs-dev-events

#### Populating sample restaurants

1. Click the "Sign in" button in the top right corner and sign in.
2. In the dropdown menu in the top right menu, select "Add sample restaurants".
