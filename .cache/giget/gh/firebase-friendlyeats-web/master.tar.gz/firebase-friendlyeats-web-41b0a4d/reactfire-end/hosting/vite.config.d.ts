declare const _default: import('vite').UserConfigExport;
export default _default;
